import { GiMeshBall, GiAbstract013, GiMazeCornea, GiMovementSensor, GiSpinningBlades, GiTripleYin,GiCircularSawblade } from 'react-icons/gi'
import { GrCloudlinux } from 'react-icons/gr'

// no rotate
import { GiNinjaHead, GiOverkill } from 'react-icons/gi'
import { SiInvoiceninja } from 'react-icons/si'

export const logoIcon = GrCloudlinux
