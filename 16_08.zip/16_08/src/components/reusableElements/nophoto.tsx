import nophoto from '../../assets/images/catSamurai_4.webp'
export { nophoto }
