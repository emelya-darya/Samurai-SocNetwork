export const shuffleArray = function (array: Array<any>) {
   array.sort(() => Math.random() - 0.5)
}

export const colorsAvatars:Array<string> = ['#38A169', '#F0772B', '#38B2AC', '#3182CE', '#00A3C4', '#805AD5']
