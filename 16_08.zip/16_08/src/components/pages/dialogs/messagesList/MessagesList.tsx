import React from 'react'
import c from './messagesList.module.scss'
import { Preloader } from '../../../reusableElements/preloaders/main/Preloader'
import { PreloaderSmall } from '../../../reusableElements/preloaders/small/PreloaderSmall'
import { useDispatch, useSelector } from 'react-redux'
import { GlobalStateType } from '../../../../store/redux/reduxStore'
import { DialogsAC } from '../../../../store/redux/dialogs/dialogsReducer'

type MessagesListPropsType = {
   userId: number
}
const MessagesList: React.FC<MessagesListPropsType> = ({ userId }) => {
   //ошибки
   const { errOnSendMessage, errOnLoadingFirstMessagesPortion, errOnLoadingExtraMessagesPortion } = useSelector(
      (state: GlobalStateType) => state.forErrorsData.dialogsErrors
   )

   const { companionData } = useSelector((state: GlobalStateType) => state.forDialogsData.messagesListData)

   const dispatch = useDispatch()
   React.useEffect(() => {
      dispatch(DialogsAC.getInitialDataForMessagesPage(userId))
   })
   return (
      <>
         <h1 className={c.title}>Messages list</h1>
         <p className={c.warn}>*working with REST API, not real time</p>
         <p>{userId}</p>
         <div className={c.messagesCompanionBlock}>
            <div className={c.companionInfo}>
               <div className={c.backLink}></div>
               <div className={c.nameLastVisit}>
                  <p className={c.name}>{companionData?.userName}</p>
                  <p className={c.lastVisit}>Last seen 15 Feb 2020</p>
               </div>
               <div className={c.avatarWr}></div>
            </div>
         </div>
         <Preloader color='#000' size={20} minHeight='30px' />
         <PreloaderSmall color='#000' size={20} minHeight='30px' />
      </>
   )
}

export { MessagesList }
