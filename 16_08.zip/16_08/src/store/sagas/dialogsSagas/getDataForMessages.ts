import { put, select, takeLeading } from 'redux-saga/effects'
import { GET_INITIAL_DATA_FOR_MESSAGES_PAGE } from '../../redux/dialogs/constants'
import { GlobalStateType } from '../../redux/reduxStore'
import { DialogsListItemType } from '../../redux/storeTypes'
import { DialogsAC } from '../../redux/dialogs/dialogsReducer'

const sagaWorkerGetInitalDataForMessagesPage = function* (
   action: ReturnType<typeof DialogsAC.getInitialDataForMessagesPage>
) {
   // ошибка
   // загрузка
   try {
      let dialogsFromState: Array<DialogsListItemType> = yield select(
         (state: GlobalStateType) => state.forDialogsData.dialogsListData.items
      )
      let companionData = dialogsFromState.find(dialog => dialog.id == action.userId) || null

      if (!companionData) {
         yield put(DialogsAC.getDialogsList())
         dialogsFromState = yield select((state: GlobalStateType) => state.forDialogsData.dialogsListData.items)
         companionData = dialogsFromState.find(dialog => dialog.id == action.userId) || null
      }

      if (!companionData) throw new Error('У вас нет диалога с этим пользователем')

      yield put(DialogsAC.setCompanionData(companionData))
   } catch (err: any) {
      // обработка ошибки
   }
   // конец загрузки
}

export const sagaWatcherGetInitalDataForMessagesPage = function* () {
   yield takeLeading(GET_INITIAL_DATA_FOR_MESSAGES_PAGE, sagaWorkerGetInitalDataForMessagesPage)
}
