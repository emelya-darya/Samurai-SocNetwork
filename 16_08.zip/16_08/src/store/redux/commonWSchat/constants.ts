export const CREATE_WS_CHANNEL = 'forCommonWSChatData/CREATE_WS_CHANNEL'
export const SET_IS_OPEN_WS_CHANNEL = 'forCommonWSChatData/SET_IS_OPEN_WS_CHANNEL'
export const SET_IS_IN_PROGRESS_OPEN_WS_CHANNEL = 'forCommonWSChatData/SET_IS_IN_PROGRESS_OPEN_WS_CHANNEL'

export const ADD_MESSAGES = 'forCommonWSChatData/ADD_MESSAGES'

export const OPEN_EVENT = 'forCommonWSChatData/OPEN_EVENT'
export const MESSAGE_EVENT = 'forCommonWSChatData/MESSAGE_EVENT'
export const CLOSE_EVENT = 'forCommonWSChatData/CLOSE_EVENT'
export const ERROR_EVENT = 'forCommonWSChatData/ERROR_EVENT'

export const CLEAR_MESSAGES = 'forCommonWSChatData/CLEAR_MESSAGES'
